package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;

public class SparkDriver {

	public static void main(String[] args) {

		Logger.getLogger("org").setLevel(Level.OFF);
		Logger.getLogger("akka").setLevel(Level.OFF);

		String inUsers;
		String inMovies;
		String inWatchedMovies;
		String outputPathPart1;
		String outputPathPart2;

		inUsers = "exam_ex2_data/Users.txt";
		inMovies = "exam_ex2_data/Movies.txt";
		inWatchedMovies = "exam_ex2_data/WatchedMovies.txt";

		outputPathPart1 = "outPart1/";
		outputPathPart2 = "outPart2/";

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam - Exercise #2").setMaster("local");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		// *****************************************
		// Exercise 2 - Part 1
		// *****************************************

		JavaRDD<String> filein = sc.textFile(inWatchedMovies).cache();
		
		JavaRDD<String> a = filein.filter(line -> {
			String[] fields = line.split(",");
			String data = fields[2];
			if(data.compareTo("2015/09/17")>=0 && data.compareTo("2020/09/16")<=0) return true;
			else return false;
		});
		
		JavaPairRDD<String, Integer> b = a.mapToPair(line -> {
			String[] fields = line.split(",");
			String mid = fields[1];
			String anno = fields[2].split("/")[0];
			return new Tuple2<String,Integer>(mid+","+anno, 1);
		}).reduceByKey((x,y)->x+y);
		
		JavaPairRDD<String,Integer> c = b.mapToPair(line -> {
			String mid = line._1().split(",")[0];
			Integer anno = Integer.parseInt( line._1().split(",")[1] );
			int numUsers = line._2();
			
			//se >1000 come value metto l'anno, se <1000 come value metto 10: 
			//in questo modo solo se il risultato è compreso tra 2015 e 2020 ho i film visti solo in un anno più di 1000 volte
			if(numUsers>1000) return new Tuple2<String,Integer>(mid, anno);
			else return new Tuple2<String,Integer>(mid,10);
		}).reduceByKey((x,y)->x+y);
		
		JavaPairRDD<String,Integer> d = c.filter(line -> {
			if(line._2()>=2015 && line._2()<=2020) return true;
			else return false;
		});
		
		d.saveAsTextFile(outputPathPart1);
		
		//PARTE B
		
		JavaRDD<String> e = filein.map(line -> {
			String[] fields = line.split(",");
			String user = fields[0];
			String mid = fields[1];
			String anno = fields[2].split(",")[0];
			return new String(user+","+mid+","+anno);
		}).distinct();
		
		JavaPairRDD<String,Integer> f = e.mapToPair(line -> {
			String mid = line.split(",")[1];
			String anno = line.split(",")[2];
			return new Tuple2<String,Integer>(mid+","+anno, 1);
		}).reduceByKey((x,y)-> x+y);//no cache() perchè anche se viene usato due volte non si usano azioni
		
		JavaPairRDD<String,Integer> g = f.mapToPair(line -> {
			return new Tuple2<String,Integer>(line._1().split(",")[1], line._2());
		}).reduceByKey((x,y)-> {
			if(x>y) return x;
			else return y;
		});
		
		JavaPairRDD<String,MidNumUsers> h = f.mapToPair(line -> {
			MidNumUsers tmp = new MidNumUsers(line._1().split(",")[0], line._2());
			return new Tuple2<String,MidNumUsers>(line._1().split(",")[1], tmp);
		});
		
		JavaPairRDD<String,Tuple2<MidNumUsers,Integer>> i = h.join(g);
		
		JavaPairRDD<String,Integer> l = i.mapToPair(line -> {
			String mid = line._2()._1().mid;
			int view1 = line._2()._1().numUsers;
			int view2 = line._2()._2();
			if(view1==view2) return new Tuple2<String,Integer>(mid,1);
			else return new Tuple2<String,Integer>(mid,0);
		}).reduceByKey((x,y)-> x+y).filter(line -> {
			if(line._2()>=2) return true;
			else return false;
		});
		
		l.keys().saveAsTextFile(outputPathPart2);
		
		
		
		
		
		
		
	}

	
}
