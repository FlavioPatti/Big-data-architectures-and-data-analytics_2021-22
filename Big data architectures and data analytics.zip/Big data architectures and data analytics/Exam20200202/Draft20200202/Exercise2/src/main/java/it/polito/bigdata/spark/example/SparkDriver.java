package it.polito.bigdata.spark.example;

import org.apache.spark.api.java.*;
import org.apache.spark.SparkConf;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import scala.Tuple2;

public class SparkDriver {

	public static void main(String[] args) {
		Logger.getLogger("org").setLevel(Level.OFF);
		Logger.getLogger("akka").setLevel(Level.OFF);

		String actionsPath, appsPath;
		String output1Path, output2Path;

		actionsPath = args[0];
		appsPath = args[1];
		output1Path = args[2];
		output2Path = args[3];

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Exam 20220202 - Exercise #2").setMaster("local");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		//PARTE A
		
		JavaRDD<String> actions = sc.textFile(actionsPath);
		JavaRDD<String> appsRDD = sc.textFile(appsPath);
		
		JavaRDD<String> RDD2021 = actions.filter(line -> {
			
		String[] fields = line.split(",");
		String anno = fields[2].split("/")[0];
		String action = fields[3];
		
		if(anno.compareTo("2021")==0 && (action.toLowerCase().compareTo("install")==0 || action.toLowerCase().compareTo("remove")==0)) return true;
		else return false;
			
		});
		
		JavaPairRDD<String,InstallRemove> a = RDD2021.mapToPair(line -> {
			String[] fields = line.split(",");
			String app = fields[1];
			String mese = fields[2].split("/")[1];
			String action = fields[3];
			InstallRemove tmp = new InstallRemove(0,0);
			if(action.toLowerCase().compareTo("install")==0)
				tmp.num_install++;
				else
				tmp.num_remove++;
			
				return new Tuple2<String,InstallRemove>(app+","+mese,tmp);
		});
		
		JavaPairRDD<String,InstallRemove> b = a.reduceByKey((x,y)-> {
		return new InstallRemove(x.num_install+y.num_install,x.num_remove+y.num_remove);	
		});
		
		JavaPairRDD<String,Integer> c = b.mapToPair(line -> {
			if(line._2().num_install>line._2().num_remove) return new Tuple2<String,Integer>(line._1().split(",")[0],0);
			else return new Tuple2<String,Integer>(line._1().split(",")[0],1);
		});
		
		JavaPairRDD<String,Integer> d = c.reduceByKey((x,y)-> x+y);
		
		JavaPairRDD<String,Integer> e = d.filter(line -> {
			if(line._2()==12) return true;
			else return false;
		});
		
		JavaPairRDD<String, String> appIdName = appsRDD.mapToPair(line -> {
			String[] fields = line.split(",");
			return new Tuple2<>(fields[0], fields[1]);
		});
		
		JavaPairRDD<String, String> res1 = e.join(appIdName).mapToPair(t -> new Tuple2<String,String>(t._1(), t._2()._2()));

		res1.saveAsTextFile(output1Path);
		
		//PARTE B
		//rileggo il contenuto di action ma non cacho
		//cacho solo rdd che uso più volte 
		
		JavaRDD<String> installRDD = actions.filter( line-> {
			String[] fields = line.split(",");
			String action = fields[3];
			if(action.toLowerCase().compareTo("install")==0) return true;
			else return false;
			
		});
		
		JavaPairRDD<String, AfterBefore> f = installRDD.mapToPair(line -> {
			String data = line.split(",")[2].split("-")[0];
			String app = line.split(",")[1];
			String user = line.split(",")[0];
			AfterBefore tmp = new AfterBefore(0,0);
			if(data.compareTo("31/12/2021")>0) tmp.after++;
			else tmp.before++;
			return new Tuple2<String,AfterBefore>(app+","+user, tmp);
		});
		
		JavaPairRDD<String,AfterBefore> g = f.reduceByKey((x,y)-> {
			return new AfterBefore(x.after+y.after,x.before+y.before);
		}).filter(line -> {
			if(line._2().after>0 && line._2().before==0) return true;
			else return false;
		});
		
		JavaPairRDD<String,Integer> h = g.mapToPair(line -> {
			return new Tuple2<String,Integer>(line._1().split(",")[0], 1);
		}).reduceByKey((x,y)-> x+y).cache(); //in questo caso questo rdd lo cacho perchè lo utilizzo due volte(2 azioni)
		
		int max = h.values().reduce((x,y)-> {
			if(x>y) return x;
			else return y;
		});
		
		JavaPairRDD<String,Integer> i = h.filter(line -> {
			if(line._2()==max) return true;
			else return false;
		});
		
		i.saveAsTextFile(output2Path);
		
		
	
		
		sc.close();
	}
}
