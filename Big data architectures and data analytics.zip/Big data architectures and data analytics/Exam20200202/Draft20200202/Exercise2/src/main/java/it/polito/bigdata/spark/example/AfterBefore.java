package it.polito.bigdata.spark.example;

public class AfterBefore {
	
	int after;
	int before;
	public AfterBefore(int after, int before) {
		
		this.after = after;
		this.before = before;
	}
	
	

}
