package it.polito.bigdata.spark.example;

public class InstallRemove {
	
	int num_install;
	int num_remove;

	public InstallRemove(int num_install, int num_remove) {
		this.num_install = num_install;
		this.num_remove = num_remove;
	}
	
	
	

}
