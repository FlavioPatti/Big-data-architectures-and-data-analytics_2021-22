package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;

public class SparkDriver {

	public static void main(String[] args) {

		Logger.getLogger("org").setLevel(Level.OFF);
		Logger.getLogger("akka").setLevel(Level.OFF);

		String inProdPlants;
		String inRobots;
		String inFailures;
		String outputPathPart1;
		String outputPathPart2;
		inProdPlants = "exam_ex2_data/ProductionPlants.txt";
		inRobots = "exam_ex2_data/Robots.txt";
		inFailures = "exam_ex2_data/Failures.txt";

		outputPathPart1 = "outPart1/";
		outputPathPart2 = "outPart2/";
		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam - Exercise #2").setMaster("local");
		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		/**********/
		/* Part 1 */
		/**********/

		JavaRDD<String> readFileRDD = sc.textFile(inFailures);
		JavaRDD<String> readRobotRDD = sc.textFile(inRobots);
		JavaRDD<String> readProd = sc.textFile(inProdPlants);
		
		JavaRDD<String> RDD2020 = readFileRDD.filter(line -> {
			String[] fields = line.split(",");
			String anno = fields[2].split("/")[0];
			if(anno.compareTo("2020")==0) return true;
			else return false;
		});
		
		JavaPairRDD<String,Integer> aa = RDD2020.mapToPair(line -> {
			String[] fields = line.split(",");
			String rid = fields[0];
			return new Tuple2<String,Integer>(rid,1);
		}).reduceByKey((x,y)-> x+y).cache();
		
		JavaPairRDD<String,Integer> a = aa.filter(line -> {
			if(line._2()>50) return true;
			else return false;
		});
		
		JavaPairRDD<String,String> b = readRobotRDD.mapToPair(line -> {
			String[] fields = line.split(",");
			String rid = fields[0];
			String pid = fields[1];
			return new Tuple2<String,String> (rid,pid);
		}).cache();
		
		JavaPairRDD<String,Tuple2<Integer,String>> c = a.join(b);
		
		JavaRDD<String> d = c.map(line -> line._2()._2()).distinct();
		
		d.saveAsTextFile(outputPathPart1);
		
		//PARTE B
		
		JavaPairRDD<String, Tuple2<String,Integer>> e = b.join(a);
		
		JavaPairRDD<String,Integer> f = e.mapToPair(line -> {
			return new Tuple2<String,Integer>(line._2()._1(), 1);
		}).reduceByKey((x,y)-> x+y);
		
		JavaPairRDD<String,Integer> g = readProd.mapToPair(line -> {
			String pid = line.split(",")[0];
			return new Tuple2<String,Integer>(pid,0);
		});
		
		JavaPairRDD<String,Integer> h = g.subtractByKey(f);
		
		JavaPairRDD<String,Integer> i = f.union(h);
		
		i.saveAsTextFile(outputPathPart2);
		
		
		
		
		
		
		
		sc.close();
	}
}
