package it.polito.bigdata.spark;

public class MaxMin {
	
	int max;
	int min;
	
	public MaxMin(int max, int min) {
		this.max = max;
		this.min = min;
	}

}
