package it.polito.bigdata.spark;

import org.apache.spark.api.java.*;
import org.apache.spark.SparkConf;
import scala.Tuple2;

public class SparkDriver {

    public static void main(String[] args) {
        String salesPath, motorbikesPath;
        String outputPath1, outputPath2;

        salesPath = args[0];
        motorbikesPath = args[1];
        outputPath1 = args[2];
        outputPath2 = args[3];

        SparkConf conf = new SparkConf().setAppName("Exam20210630 - Spark");

        JavaSparkContext sc = new JavaSparkContext(conf);
        
        //PARTE A
        
        JavaRDD<String> file = sc.textFile(salesPath);
        JavaRDD<String> file2 = sc.textFile(motorbikesPath);
        
        JavaRDD<String> RDD2020EU = file.filter(line -> {
        	String[] fields = line.split(",");
        	String eu = fields[6];
        	String anno = fields[3].split("/")[0];
        	if(eu.toLowerCase().compareTo("t")==0 && anno.compareTo("2020")==0) return true;
        	else return false;
        });
        
        JavaPairRDD<String,MaxMin> a = RDD2020EU.mapToPair(line -> {
        	String[] fields = line.split(",");
        	String model = fields[3];
        	int prezzo = Integer.parseInt(fields[5]);
        	MaxMin tmp = new MaxMin(prezzo,prezzo);
        	return new Tuple2<String,MaxMin>(model, tmp);
        });
        
        JavaPairRDD<String,MaxMin> b = a.reduceByKey((x,y)-> {
        	MaxMin tmp = new MaxMin(0,0);
        	if(x.max>y.max) tmp.max = x.max;
        	else tmp.max = y.max;
        	if(x.min< y.min) tmp.min = x.min;
        	else tmp.min = y.min;
        	return tmp;
        });
        
        JavaPairRDD<String,MaxMin> c = b.filter(line -> {
        	if(line._2().max-line._2().min>=5000) return true;
        	else return false;
        });
        
        c.keys().saveAsTextFile(outputPath1);
        
        //PARTE B
        
        JavaPairRDD<String,Integer> d = file.mapToPair(line -> {
        	String[] fields = line.split(",");
        	String model = fields[2];
        	return new Tuple2<String,Integer>(model,1);
        }).reduceByKey((x,y)-> x+y);
        
        JavaPairRDD<String,Integer> e = d.filter(line -> {
        	if(line._2()>10) return true;
        	else return false;
        });
        
        JavaPairRDD<String,String> f = file2.mapToPair(line -> {
        	String[] fields = line.split(",");
        	String model = fields[0];
        	String manu = fields[1];
        	return new Tuple2<String,String>(model,manu);
        });
      
        JavaPairRDD<String,String> g = f.subtractByKey(e);
        
        JavaPairRDD<String,Integer> h = g.mapToPair(line -> {
        	return new Tuple2<String,Integer>(line._2(), 1);
        }).reduceByKey((x,y)-> x+y).filter(line -> {
        	if(line._2()>=15) return true;
        	else return false;
        });
        
        h.saveAsTextFile(outputPath2);
        
        
        
        sc.close();
    }
}
