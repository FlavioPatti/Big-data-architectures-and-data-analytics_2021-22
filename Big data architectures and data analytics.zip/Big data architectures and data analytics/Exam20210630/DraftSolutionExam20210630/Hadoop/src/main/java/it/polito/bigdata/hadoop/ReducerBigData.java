package it.polito.bigdata.hadoop;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 * Basic MapReduce Project - Reducer
 */
class ReducerBigData extends Reducer<Text, Text, Text, NullWritable> {

	@Override
	protected void reduce(Text key, // Input key type
			Iterable<Text> values, // Input value type
			Context context) throws IOException, InterruptedException {

		int cnt_t = 0;
		int cnt_f = 0;
		for(Text value: values) {
			if(value.toString().compareTo("T")==0) cnt_t++;
			if(value.toString().compareTo("F")==0) cnt_f++;
		}
	
	if(cnt_t>=10000 && cnt_f>=10000) context.write(key, NullWritable.get());
	
	}
}
