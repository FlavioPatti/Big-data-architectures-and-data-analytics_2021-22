package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;

import org.apache.spark.SparkConf;

public class SparkDriver {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		String inputPathServers;
		String inputPathFailures;
		String outputPathPartA;
		String outputPathPartB;

		inputPathServers = args[0];
		inputPathFailures = args[1];
		outputPathPartA = args[2];
		outputPathPartB = args[3];

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam 2018_07_16 - Exercise #2");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		// *****************************************
		// Exercise 2 - Part A
		// *****************************************

		// Read the content of servers.txt
		JavaRDD<String> servers = sc.textFile(inputPathServers);
		JavaRDD<String> failures = sc.textFile(inputPathFailures);
		
		JavaRDD<String> rdd2017 = failures.filter(line -> {
			if(line.split(",")[0].split("/")[0].compareTo("2017")==0) return true;
			else return false;
		}).cache();
		
		JavaPairRDD<String,Integer> a = rdd2017.mapToPair(line -> {
			return new Tuple2<String,Integer>(line.split(",")[2], 1);
		}).reduceByKey((x,y)-> x+y);
		
		JavaPairRDD<String,String> b = servers.mapToPair(line -> {
			String sid = line.split(",")[0];
			String dc = line.split(",")[2];
			
			return new Tuple2<String,String>(sid,dc);
		});
		
		JavaPairRDD<String,Tuple2<String,Integer>> c = b.join(a);
		
		JavaPairRDD<String,Integer> d = c.mapToPair(line -> {
			return new Tuple2<String,Integer>(line._2()._1(), line._2()._2());
		}).reduceByKey((x,y)-> x+y).filter(line -> {
			if(line._2() >365) return true;
			else return false;
		});
		
		//PARTE B
		
		JavaPairRDD<String,NumFailuresDowntime> e = rdd2017.mapToPair(line -> {
			String sid = line.split(",")[2];
			String mese = line.split(",")[0].split("/")[1];
			int down = Integer.parseInt(line.split(",")[4]);
			NumFailuresDowntime tmp = new NumFailuresDowntime(1,down);
			return new Tuple2<String,NumFailuresDowntime>(sid+","+mese,tmp);
		}).reduceByKey((x,y)-> {
			return new NumFailuresDowntime(x.numFailures+y.numFailures, x.downtimeMinutes+y.downtimeMinutes);
		}).filter(line -> {
			if(line._2().numFailures>=2) return true;
			else return false;
		});
		
		JavaPairRDD<String,NumFailuresDowntime> f = e.mapToPair(line -> {
			NumFailuresDowntime tmp = new NumFailuresDowntime(1, line._2().downtimeMinutes);
			return new Tuple2<String,NumFailuresDowntime>(line._1().split(",")[0], tmp);
		}).reduceByKey((x,y)-> {
			return new NumFailuresDowntime(x.numFailures+y.numFailures, x.downtimeMinutes+y.downtimeMinutes);
		}).filter(line -> {
			if(line._2().numFailures==12 && line._2().downtimeMinutes>=1440) return true;
			else return false;
		});
		
		sc.close();
	}
}
