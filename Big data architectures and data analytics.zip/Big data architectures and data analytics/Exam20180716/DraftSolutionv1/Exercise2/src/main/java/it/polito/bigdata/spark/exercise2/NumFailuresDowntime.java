package it.polito.bigdata.spark.exercise2;

import java.io.Serializable;

@SuppressWarnings("serial")
public class NumFailuresDowntime implements Serializable {
	 int numFailures;
	 int downtimeMinutes;

	public NumFailuresDowntime(int numFailures, int downtimeMinutes) {
		this.numFailures = numFailures;
		this.downtimeMinutes = downtimeMinutes;
	}


	public String toString() {
		return new String("num. failures:" + numFailures + " tot. downtime:" + downtimeMinutes);
	}

}
