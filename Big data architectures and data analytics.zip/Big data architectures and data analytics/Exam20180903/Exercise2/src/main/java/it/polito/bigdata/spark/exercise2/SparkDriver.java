package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;

import java.util.ArrayList;

import org.apache.spark.SparkConf;

public class SparkDriver {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		String inputPathPrices;
		String outputPathPartA;
		String outputPathPartB;

		inputPathPrices = args[0];
		outputPathPartA = args[1];
		outputPathPartB = args[2];

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam 2018_09_03 - Exercise #2");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		// *****************************************
		// Exercise 2 - Part A
		// *****************************************

		// Read the content of stocks_prices.txt
		JavaRDD<String> stockPrices = sc.textFile(inputPathPrices);
		
		JavaRDD<String> rdd2017 = stockPrices.filter(line -> {
			if(line.split(",")[1].split("/")[0].compareTo("2017")==0) return true;
			else return false;
		});
		
		JavaPairRDD<String,MinMaxPrices> a = rdd2017.mapToPair(line -> {
			String sid = line.split(",")[0];
			String data = line.split(",")[1];
			int price = Integer.parseInt(line.split(",")[3]);
			MinMaxPrices tmp = new MinMaxPrices(price,price);
			return new Tuple2<String,MinMaxPrices>(sid+","+data, tmp);
		}).reduceByKey((x,y)-> {
			MinMaxPrices tmp = new MinMaxPrices(0,0);
		if(x.maxPrice>y.maxPrice) tmp.maxPrice = x.maxPrice;
		else tmp.maxPrice = y.maxPrice;
		if(x.minPrice< y.minPrice) tmp.minPrice = x.minPrice;
		else tmp.minPrice = y.minPrice;
		return tmp;
		});
		
		JavaPairRDD<String,Double> b = a.mapToPair(line -> {
			return new Tuple2<String,Double>(line._1(), line._2().maxPrice-line._2().minPrice);
		}).cache();
		
		JavaPairRDD<String,Double> c = b.filter(line -> {
			if(line._2() >10 ) return true;
			else return false;
		});
		
		JavaRDD<String> d = c.map(line -> line._1().split(",")[0]).distinct();
		
		//PARTE B
		
		JavaPairRDD<String,Double> e = b.flatMapToPair(line -> {
			ArrayList<Tuple2<String,Double>> list = new ArrayList<>();
			String data = line._1().split(",")[1];
			String sid = line._1().split(",")[0];
			
			list.add(new Tuple2<String,Double>(sid+","+data, line._2()));
			
			String ieri = DateTool.previousDate(data);
			list.add(new Tuple2<String,Double>(sid+","+ieri, line._2()));
			
			return list.iterator();
		});
		
		JavaPairRDD<String,Iterable<Double>> f = e.groupByKey().filter(line -> {
			Double dpv1 = null;
			Double dpv2 = null;
			
			for(Double dpv: line._2()) {
				
			if(dpv2==null && dpv1!=null) dpv2 = dpv;
				
				if(dpv1==null) dpv1 = dpv;
			}
			
			//dim = 2
			if(dpv2!=null) {
				if(dpv1-dpv2<=0.1) return true;
				else return false;
			}else return false;
		});
		
		f.keys().saveAsObjectFile(outputPathPartB);
		
		sc.close();
	}
}

