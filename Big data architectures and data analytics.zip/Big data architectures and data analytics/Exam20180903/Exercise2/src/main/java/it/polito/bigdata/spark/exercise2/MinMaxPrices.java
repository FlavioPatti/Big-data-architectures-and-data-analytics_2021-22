package it.polito.bigdata.spark.exercise2;

import java.io.Serializable;

@SuppressWarnings("serial")
public class MinMaxPrices implements Serializable {
	public double minPrice;
	public double maxPrice;

	public MinMaxPrices(double minPrice, double maxPrice) {
		this.minPrice = minPrice;
		this.maxPrice = maxPrice;
	}

}
