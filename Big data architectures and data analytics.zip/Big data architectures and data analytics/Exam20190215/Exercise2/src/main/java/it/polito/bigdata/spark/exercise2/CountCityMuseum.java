package it.polito.bigdata.spark.exercise2;

import java.io.Serializable;

@SuppressWarnings("serial")
public class CountCityMuseum implements Serializable {
	 int numCities;
	 int numMuseumPOIs;
	
	public CountCityMuseum(int numCities, int numMuseumPOIs) {
		this.numCities = numCities;
		this.numMuseumPOIs = numMuseumPOIs;

	}

	


	public String toString() {
		return new String(this.numCities + " " + this.numMuseumPOIs);
	}

}
