package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;
import org.apache.spark.SparkConf;

public class SparkDriver {

	public static void main(String[] args) {

		String inputPathPOIs;
		String outputPathPartA;
		String outputPathPartB;

		inputPathPOIs = args[0];
		outputPathPartA = args[1];
		outputPathPartB = args[2];

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam 2019_02_15 - Exercise #2");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		// *****************************************
		// Exercise 2 - Part A
		// *****************************************
		
		JavaRDD<String> RDD = sc.textFile(inputPathPOIs);
		
		JavaRDD<String> filterRDD = RDD.filter(line -> {
			String[] fields = line.split(",");
			String city = fields[2];
			String sub = fields[5];
			if(city.compareTo("italy")==0 && (sub.compareTo("taxi")==0 || sub.compareTo("busstop")==0) ) return true;
			else return false;
		});
		
		JavaPairRDD<String,CountTaxiBusstop> a = filterRDD.mapToPair(line -> {
			String[] fields = line.split(",");
			String city = fields[2];
			String sub = fields[5];
			CountTaxiBusstop cnt = new CountTaxiBusstop(0,0);
			if(sub.compareTo("taxi")==0) cnt.numTaxiPOIs++;
			else cnt.numBusstopPOIs++;
			return new Tuple2<String,CountTaxiBusstop>(city, cnt);
		}).reduceByKey((x,y)-> {
			return new CountTaxiBusstop(x.numTaxiPOIs+y.numTaxiPOIs, x.numBusstopPOIs+y.numBusstopPOIs);
		}).filter(line -> {
			if(line._2().numTaxiPOIs>0 && line._2().numBusstopPOIs==0) return true;
			else return false;
		});
		
		//PARTE B
		
		JavaRDD<String> b = RDD.filter(line -> {
			String[] fields = line.split(",");
			String city = fields[2];
			String sub = fields[5];
			if(city.compareTo("italy")==0 && sub.compareTo("museum")==0) return true;
			else return false;
		});
		
		JavaPairRDD<String,Integer> c = b.mapToPair(line -> {
			String[] fields = line.split(",");
			String city = fields[2];
			return new Tuple2<String,Integer>(city,1);
		}).reduceByKey((x,y)-> x+y);
		
		JavaRDD<CountCityMuseum> d = c.map(line -> {
			CountCityMuseum cnt = new CountCityMuseum(1, line._2());
			return cnt;
		});
		
		CountCityMuseum tmp = d.reduce((x,y)-> {
			return new CountCityMuseum(x.numCities+y.numCities, x.numMuseumPOIs+y.numMuseumPOIs);
		});
		
		double avg = tmp.numMuseumPOIs/ tmp.numCities;
		
		JavaPairRDD<String,Integer> e = c.filter(line -> {
			if(line._2()>avg) return true;
			else return false;
		});
		
		
		
		
		
		sc.close();
	}
}
