package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;

import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;

public class SparkDriver {

	
	public static void main(String[] args) {

		Logger.getLogger("org").setLevel(Level.OFF);
		Logger.getLogger("akka").setLevel(Level.OFF);

		//String inputPathBooks;
		String inputPathPurchases;
		String outputPathPart1;
		String outputPathPart2;

		//inputPathBooks = "exam_ex2_data/Books.txt";
		inputPathPurchases = "exam_ex2_data/Purchases.txt";
		outputPathPart1 = "outPart1/";
		outputPathPart2 = "outPart2/";

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam - Exercise #2").setMaster("local");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		// *****************************************
		// Exercise 2 - Part 1
		// *****************************************

		// Read the content of Purchases.txt
		JavaRDD<String> purchasesRDD = sc.textFile(inputPathPurchases);

		JavaRDD<String> rdd2018 = purchasesRDD.filter(line -> {
			String[] fields = line.split(",");
			String data = fields[2];
			if( data.startsWith("2018")) return true;
			else return false;
		});
		
		JavaPairRDD<String,Integer> a = rdd2018.mapToPair(line -> {
			return new Tuple2<String,Integer>(line.split(",")[1]+","+line.split(",")[2], 1);
		}).reduceByKey((x,y)-> x+y).cache();
		
		JavaPairRDD<String,Integer> b = a.mapToPair(line -> {
			return new Tuple2<String,Integer>(line._1().split(",")[0], line._2());
		}).cache().reduceByKey((x,y)-> {
			if(x>y) return x; 
			else return y;
		});
		
		//PARTE B
		
		JavaPairRDD<String,Integer> c = rdd2018.mapToPair(line -> {
			String[] fields = line.split(",");
			String bid = fields[1];
			return new Tuple2<String,Integer>(bid,1);
		}).reduceByKey((x,y)-> x+y);
		
		JavaPairRDD<String,dataSum> d = a.mapToPair(line -> {
			String bid = line._1().split(",")[0];
			String date = line._1().split(",")[1];
			int sum = line._2();
			return new Tuple2<String,dataSum> (bid, new dataSum(date, sum) );
		});
		
		JavaPairRDD<String,Tuple2<dataSum,Integer>> e = d.join(c);
		
		JavaPairRDD<String,Tuple2<dataSum,Integer>> f = e.filter(line -> {
			if(line._2()._1.sum> 0.1*line._2()._2()) return true;
			else return false;
		});
		
		JavaPairRDD<String,Integer> g = f.flatMapToPair(line -> {
			ArrayList<Tuple2<String,Integer>> list = new ArrayList<>();
			String data = line._2()._1().data;
			String bid = line._1();
			list.add(new Tuple2<String,Integer>(bid+","+data,1));
			
			String ieri = DateTool.previousDeltaDate(data, -1);
			list.add(new Tuple2<String,Integer>(bid+","+ieri,1));
			
			String laltroieri = DateTool.previousDeltaDate(data, -1);
			list.add(new Tuple2<String,Integer>(bid+","+laltroieri,1));
			
			return list.iterator();
		});
		
		JavaPairRDD<String,Integer> h = g.reduceByKey((x,y)-> x+y).filter(line -> {
			if(line._2()==3) return true;
			else return false;
		});
		
		
		
		sc.close();
	}
}
