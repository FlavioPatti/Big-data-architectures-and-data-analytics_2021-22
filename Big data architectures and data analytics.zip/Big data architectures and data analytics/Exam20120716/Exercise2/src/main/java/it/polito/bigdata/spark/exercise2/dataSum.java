package it.polito.bigdata.spark.exercise2;

import java.io.Serializable;

public class dataSum implements Serializable{
	public String data;
	public int sum;
	
	public dataSum(String data, int sum) {
		this.data = data;
		this.sum = sum;
	}
	
	
}