package it.polito.bigdata.hadoop.exercise1;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * Exercise 1 - Mapper
 */
class MapperBigData extends
		Mapper<LongWritable, // Input key type
				Text, // Input value type
				Text, // Output key type
				DoubleWritable> {// Output value type

	protected void map(LongWritable key, // Input key type
			Text value, // Input value type
			Context context) throws IOException, InterruptedException {

		// Split data
		// stockId,date,hour:minute,price
		// Example: FCAU,2016/06/20,16:10,10.43
	
		String[] fields = value.toString().split(",");
		String[] data = fields[1].split("/");
		String stockId = fields[0];
		String anno = data[0];
		String mese = data[1];
		double prezzo = Double.parseDouble(fields[3]);
		
		if( anno == "2016") {
			context.write(new Text(stockId+","+mese), new DoubleWritable(prezzo));
		}
		
		
		
	}
}
