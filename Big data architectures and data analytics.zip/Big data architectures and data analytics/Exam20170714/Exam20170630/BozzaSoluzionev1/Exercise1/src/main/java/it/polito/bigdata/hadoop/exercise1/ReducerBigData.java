package it.polito.bigdata.hadoop.exercise1;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 * Exercise 1 - Reducer
 * 
 */
class ReducerBigData extends
		Reducer<Text, // Input key type
				DoubleWritable, // Input value type
				Text, // Output key type
				Text> { // Output value type

	@Override
	protected void reduce(Text key, // Input key type
			Iterable<DoubleWritable> values, // Input value type
			Context context) throws IOException, InterruptedException {
		
		double min = Double.MAX_VALUE;
		double max = Double.MIN_VALUE;
		double differenza;
		double variazione;
		
		for(DoubleWritable prezzo : values){
			if(prezzo.get()>max) max = prezzo.get(); //get-> dal writable al tipo
			if(prezzo.get()<min) min = prezzo.get();
		}
		differenza = max-min;
		variazione = 100*(max-min)/min;
		
		if(variazione <5)
		context.write(key, new Text(differenza+" "+ variazione));
	}
}
