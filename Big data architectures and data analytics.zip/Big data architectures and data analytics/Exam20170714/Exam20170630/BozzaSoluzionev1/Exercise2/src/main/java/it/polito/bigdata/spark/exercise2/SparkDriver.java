package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;

import org.apache.spark.SparkConf;

public class SparkDriver {

	public static void main(String[] args) {

		String inputPathPrices;
		String outputPathPartA;
		String outputPathPartB;
		int nw;

		inputPathPrices = args[0];
		nw = Integer.parseInt(args[1]);
		outputPathPartA = args[2];
		outputPathPartB = args[3];

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam 2016_06_30 - Exercise #2");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		// *****************************************
		// Exercise 2 - Part A
		// *****************************************

		// Read the content of Prices.txt
		JavaRDD<String> prices = sc.textFile(inputPathPrices);

		JavaRDD<String> filterPrices = prices.filter(line -> {
			
			String[] fields = line.split(",");
			String[] data = fields[1].split("/");
			String anno = data[0];
			if(anno == "2016") return true;
			else return false;
		});
		
		JavaPairRDD<String, Double> stockidData = filterPrices.mapToPair(line -> {
			String[] fields = line.split(",");
			String stockId = fields[0];
			String data = fields[1];
			double price = Double.parseDouble(fields[3]);
			
			return new Tuple2<String, Double> (stockId+"_"+ data, price);
			
		}).cache();
		
		JavaPairRDD<String,Double> minStockidData = stockidData.reduceByKey( (a,b)-> {
			if(a>b) return b;
			else return a;
		});
		
		JavaPairRDD<String,Double> sortMinStockidData = minStockidData.sortByKey(true);
		
		minStockidData.saveAsTextFile(outputPathPartA);
		
		//parte B
		
		JavaPairRDD<String,Double> maxPriceOfTheDay = stockidData.reduceByKey( (a,b) -> {
			if(a>b) return a;
			else return b;
			
		});
		
		JavaPairRDD<String, FirstDatePriceLastDatePrice> sid_woy = maxPriceOfTheDay.mapToPair(line -> {
			String stockid = line._1().split("_")[0];
			int numWeek =DateTool.weekNumber(line._1().split("_")[1]);
			String data = line._1().split("_")[1];
			double prezzo = line._2();
			FirstDatePriceLastDatePrice fdpldp = new FirstDatePriceLastDatePrice(data, prezzo, data, prezzo);
			
			return new Tuple2<String, FirstDatePriceLastDatePrice> (stockid+"_"+numWeek, fdpldp);
		});
		
		JavaPairRDD<String,FirstDatePriceLastDatePrice> reduce = sid_woy.reduceByKey( (a,b)-> {
		
			String datainA = a.firstdate;
			String datainB = b.firstdate;
			String datafinA = a.lastdate;
			String datafinB = b.lastdate;
			double prezzoinA = a.firstprice;
			double prezzoinB = b.firstprice;
			double prezzofinA = a.lastprice;
			double prezzofinB = b.lastprice;
			
			FirstDatePriceLastDatePrice x;
			if(datainA.compareTo(datainB)>0) x = new FirstDatePriceLastDatePrice(datainB,prezzoinB,datafinA,prezzofinA);
			else x = new FirstDatePriceLastDatePrice(datainA,prezzoinA,datafinB,prezzofinB);
			return x;
		});
		
		JavaPairRDD<String,Integer> verifica = reduce.mapToPair(line -> {
			
			double prezzoin = line._2().firstprice;
			double prezzofin = line._2().lastprice;
			
			if(prezzofin-prezzoin>0) return new Tuple2<String,Integer>(line._1(), 1);
			else return new Tuple2<String,Integer>(line._1(),0);
		});
		
		JavaPairRDD<String,Integer> reduceverifica = verifica.reduceByKey( (a,b)-> a+b);
		
		JavaPairRDD<String,Integer> filtro = reduceverifica.filter(line -> {
			if(line._2()>=nw) return true;
			else return false;
		});
		
		long ris = filtro.keys().count();
		
		
			
		
	
		
		
		sc.close();
	}
}
