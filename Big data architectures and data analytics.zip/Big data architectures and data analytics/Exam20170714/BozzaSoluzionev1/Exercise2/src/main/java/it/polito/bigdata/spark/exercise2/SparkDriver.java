package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;

import org.apache.spark.SparkConf;

public class SparkDriver {

	public static void main(String[] args) {

		String inputPathPrices;
		String outputPathPartA;
		String outputPathPartB;

		inputPathPrices = args[0];
		outputPathPartA = args[1];
		outputPathPartB = args[2];

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam 2016_07_14 - Exercise #2");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		// *****************************************
		// Exercise 2 - Part A
		// *****************************************
		
		//leggo temperature.txt
		JavaRDD<String> temperatures = sc.textFile(inputPathPrices);
		
		JavaPairRDD<String, MaxTempCount> cityMaxTempCount = temperatures.filter(line  -> {
			String words[] = line.split(",");
			String data = words[0];
			if(data.compareTo("2015/06/01")>0 && data.compareTo("2015/08/31")<0) return true;
			else return false;
		}).mapToPair(line -> { 
			String words[] = line.split(",");
			String city = words[1];
			String country = words[2];
			double maxTemp = Double.parseDouble(words[3]);
			MaxTempCount mtc = new MaxTempCount(maxTemp, 1);
			
			return new Tuple2<String, MaxTempCount>(city + "," + country, mtc);
		}).reduceByKey( (x, y) -> {
			MaxTempCount tmp = new MaxTempCount(x.maxTemp+y.maxTemp, x.count+y.count);
			return tmp;
		}); 
		
		cityMaxTempCount.saveAsTextFile(outputPathPartA);
		
		//PART B
		
		JavaPairRDD<String, MaxTempCount> tmp = temperatures.filter(line  -> {
			String words[] = line.split(",");
			String data = words[0];
			if(data.compareTo("2015/06/01")>0 && data.compareTo("2015/08/31")<0) return true;
			else return false;
		}).mapToPair(line -> { 
			String words[] = line.split(",");
			String country = words[2];
			double maxTemp = Double.parseDouble(words[3]);
			MaxTempCount mtc = new MaxTempCount(maxTemp, 1);
			
			return new Tuple2<String, MaxTempCount>(country, mtc);
		});
		
		JavaPairRDD<String,MaxTempCount> country_avg = tmp.reduceByKey( (a,b)-> {
			MaxTempCount mtc;
			return new MaxTempCount(a.maxTemp+b.maxTemp, a.count+b.count);
		});
		
		JavaPairRDD<String, MaxTempCount> tmp2 = temperatures.filter(line  -> {
			String words[] = line.split(",");
			String data = words[0];
			if(data.compareTo("2015/06/01")>0 && data.compareTo("2015/08/31")<0) return true;
			else return false;
		}).mapToPair(line -> { 
			String words[] = line.split(",");
			String city = words[1];
			String country = words[2];
			double maxTemp = Double.parseDouble(words[3]);
			MaxTempCount mtc = new MaxTempCount(maxTemp, 1);
			
			return new Tuple2<String, MaxTempCount>(country+","+city, mtc);
		});
		
		JavaPairRDD<String,MaxTempCount> city_avg = tmp2.reduceByKey( (a,b)-> {
			MaxTempCount mtc;
			return new MaxTempCount(a.maxTemp+b.maxTemp, a.count+b.count);
		});
		
		
		JavaPairRDD<String,CityMaxTempCount> map_city_avg = city_avg.mapToPair(line -> {
			CityMaxTempCount city = new CityMaxTempCount(line._1().split(",")[1], line._2().maxTemp, line._2().count);
			return new Tuple2<String,CityMaxTempCount>(line._1().split(",")[0], city);
		});
		
		//[ COUNTRY,  ( (CITY,MTC), (MTC) ) ]
		JavaPairRDD<String,Tuple2<CityMaxTempCount,MaxTempCount> > join = map_city_avg.join(country_avg);
		
		JavaPairRDD<String,Tuple2<CityMaxTempCount,MaxTempCount>> filter = join.filter(line -> {
			double avg_country = (double) line._2()._2().maxTemp / line._2()._2().count;
			double avg_city = (double) line._2()._1().maxTemp / line._2()._1().count;
			
			if(avg_city>avg_country+5) return true;
			else return false;
			
			
		});
		
		JavaRDD<String> ris = filter.map(line -> {
			return line._2()._1().city;
		});
		
		
		sc.close();
	}
}
