package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;

import org.apache.spark.SparkConf;

public class SparkDriver {

	public static void main(String[] args) {

		String inputBicycles;
		String inputFailures;
		String outputPathPartA;
		String outputPathPartB;

		inputBicycles = args[0];
		inputFailures = args[1];
		outputPathPartA = args[2];
		outputPathPartB = args[3];

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam 2019_07_02 - Exercise #2");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		// *****************************************
		// Exercise 2 - Part A
		// *****************************************

		// Read the content of Bicycles_Failures.txt
		JavaRDD<String> failuresRDD = sc.textFile(inputFailures);
		JavaRDD<String> bicyRDD = sc.textFile(inputBicycles);
		
		JavaRDD<String> rdd2018 = failuresRDD.filter(line -> {
			String anno = line.split(",")[0].split("/")[0];
			String component = line.split(",")[2];
			if(anno.compareTo("2018")==0 && component.compareTo("wheel")==0) return true;
			else return false;
		});
		
		JavaPairRDD<String,Integer> a = rdd2018.mapToPair(line -> {
			String[] fields = line.split(",");
			String mese = fields[0].split("/")[1];
			String bid = fields[1];
			return new Tuple2<String,Integer>(bid+","+mese,1);
		}).reduceByKey((x,y)-> x+y);
	
		JavaPairRDD<String,Integer> b = a.mapToPair(line -> {
			String bid = line._1().split(",")[0];
			if( line._2()>2) return new Tuple2<String,Integer>(bid, 1);
			else return new Tuple2<String,Integer>(bid,0);
		}).reduceByKey((x,y)-> x+y).filter(line -> {
			if(line._2()>=1) return true;
			else return false;
		});
		
		b.keys().saveAsTextFile(outputPathPartA);
		
		//PARTE B
		
		JavaRDD<String> c = failuresRDD.filter(line -> {
			String anno = line.split(",")[0].split("/")[0];
			if(anno.compareTo("2018")==0 ) return true;
			else return false;
		});
		
		JavaPairRDD<String,Integer> f = c.mapToPair(line -> {
			return new Tuple2<String,Integer>(line.split(",")[1],1);
		}).reduceByKey((x,y)-> x+y).filter(line -> {
			if(line._2()>20) return true;
			else return false;
		});
		
		JavaPairRDD<String,Integer> d = bicyRDD.mapToPair(line -> {
			return new Tuple2<String,Integer> (line.split(",")[2],1);
		}).reduceByKey((x,y)-> x+y);
		
		JavaPairRDD<String,String> e = bicyRDD.mapToPair(line -> {
			return new Tuple2<String,String>(line.split(",")[0],line.split(",")[2]);
		});
		
		JavaPairRDD<String,String> g = e.subtractByKey(f);
		
		JavaPairRDD<String,Integer> h = g.mapToPair(line -> {
			return new Tuple2<String,Integer>(line._2(),1);
		}).reduceByKey((x,y)-> x+y);
		
		JavaPairRDD<String,Tuple2<Integer,Integer>> i = d.join(h).filter(line -> {
			if(line._2()._1() == line._2()._2()) return true;
			else return false;
		});
		
		JavaRDD<String> l = i.map(line -> line._1());
		
		sc.close();
	}
}
