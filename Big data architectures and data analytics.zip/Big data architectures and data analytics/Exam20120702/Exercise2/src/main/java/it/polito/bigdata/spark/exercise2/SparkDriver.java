package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;

public class SparkDriver {

	public static void main(String[] args) {

		Logger.getLogger("org").setLevel(Level.OFF);
		Logger.getLogger("akka").setLevel(Level.OFF);

		String inputPathServers;
		String inputPathPatchesServers;
		String outputPathPart1;
		String outputPathPart2;

		inputPathServers = "exam_ex2_data/Servers.txt";
		inputPathPatchesServers = "exam_ex2_data/PatchedServers.txt";
		outputPathPart1 = "outPart1/";
		outputPathPart2 = "outPart2/";

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam - Exercise #2").setMaster("local");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		/* Write your code here */

		// *****************************************
		// Exercise 2 - Part 1
		// *****************************************

		// Read the content of PatchesServers.txt
		JavaRDD<String> patchesRDD = sc.textFile(inputPathPatchesServers).cache();
		JavaRDD<String> serversRDD = sc.textFile(inputPathServers);
		
		JavaPairRDD<String,String> c = serversRDD.mapToPair(line -> {
			return new Tuple2<String,String>(line.split(",")[0], line.split(",")[1]);
		}).cache();

		JavaRDD<String> rdd1819 = patchesRDD.filter(line -> {
			String[] fields = line.split(",");
			String data = fields[2].split("/")[0];
			if(data.compareTo("2018")==0 || data.compareTo("2019")==0) return true;
			else return false;
		});
		
		JavaPairRDD<String,Count1819> a =rdd1819.mapToPair(line -> {
			String[] fields = line.split(",");
			String data = fields[2].split("/")[0];
			String sid = fields[0];
			Count1819 tmp = new Count1819(0,0);
			if(data.compareTo("2018")==0) tmp.count18++;
			else tmp.count19++;
			return new Tuple2<String,Count1819>(sid,tmp);
		}).reduceByKey((x,y)-> {
			return new Count1819(x.count18+y.count18,x.count19+y.count19);
		}).filter(line -> {
			if( line._2().count19 < 0.5*line._2().count18) return true;
			else return false;
		});
		
		JavaPairRDD<String, Tuple2<String,Count1819>> b = c.join(a);
		
		JavaPairRDD<String,String> d = b.mapToPair(line -> {
			return new Tuple2<String,String>(line._1(), line._2()._1());
		});
		
		//PARTE B
		
		JavaPairRDD<String,Integer> e = patchesRDD.mapToPair(line -> {
			return new Tuple2<String,Integer>(line.split(",")[0]+","+line.split(",")[2], 1);
		}).reduceByKey((x,y)-> x+y).filter(line -> {
			if(line._2()>=2) return true;
			else return false;
		});
		
		JavaPairRDD<String,String> f = e.mapToPair(line -> {
			return new Tuple2<String,String>(line._1().split(",")[0], "");
		});
		
		JavaPairRDD<String,String> g = c.subtractByKey(f);
		
		long count = g.values().distinct().count();
		
		
		
		
		sc.close();
	}
}
