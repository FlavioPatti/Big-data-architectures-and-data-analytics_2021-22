package it.polito.bigdata.hadoop.exercise1;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * Exercise 1 - Mapper
 */

class MapperBigData extends
		Mapper<LongWritable, // Input key type
				Text, // Input value type
				Text, // Output key type
				IntWritable> {// Output value type

	protected void map(LongWritable key, // Input key type
			Text value, // Input value type
			Context context) throws IOException, InterruptedException {

		String[] fields = value.toString().split(",");
		String data = fields[2];
		String aero = fields[5];
		String cancellato = fields[8];
		
		//September 1, 2016 to August 31, 2017
		if(data.compareTo("2016/09/01")>0 && data.compareTo("2017/08/31")<0) {
			if(cancellato.toLowerCase().compareTo("no")==0) 
				context.write(new Text(aero),new IntWritable(0));
			else context.write(new Text(aero),new IntWritable(1));
		}
	}
}
