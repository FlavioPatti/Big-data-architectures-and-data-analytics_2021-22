package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;

import org.apache.spark.SparkConf;

public class SparkDriver {

	public static void main(String[] args) {

		String inputPathFlights;
		String inputPathAirports;
		String outputPathPartA;
		String outputPathPartB;

		inputPathFlights = args[0];
		inputPathAirports = args[1];
		outputPathPartA = args[2];
		outputPathPartB = args[3];

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam 2016_09_14 - Exercise #2");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		// *****************************************
		// Exercise 2 - Part A
		// *****************************************

		// Read the content of Flights.txt
		JavaRDD<String> voli = sc.textFile(inputPathFlights);
		
		JavaRDD<String> voliFiltrati = voli.filter(line -> {
			int delay = Integer.parseInt(line.split(",")[7]);
			if(delay>=15) return true;
			return false;
		});
		
		JavaPairRDD<String, String> ArrivoAirline = voliFiltrati.mapToPair(line -> {
			String[] fields = line.split(",");
			String aereop_arrivo = fields[6];
			String airline = fields[1];
			
			return new Tuple2<String,String>(aereop_arrivo, airline);
		});
		
		
		JavaRDD<String> aerei = sc.textFile(inputPathAirports);
		JavaRDD<String> filteredAerei = aerei.filter(line ->{
			String[] fields = line.split(",");
			String nationality = fields[3];
			
			if (nationality=="Germany") return true;
			else return false;	
		});
		
		JavaPairRDD<String,String> AirIdName = filteredAerei.mapToPair(line -> {
			String[] fields = line.split(",");
			String airId = fields[0];
			String airName = fields[1];
			
			return new Tuple2<String, String>(airId, airName);
		});
		
		JavaPairRDD<String, Tuple2<String, String>> joinedAirlines = ArrivoAirline.join(AirIdName);
		
		JavaPairRDD<String, Integer> AirportOne = joinedAirlines.mapToPair(line -> {
			String airline = line._2()._1();
			String airname = line._2()._2();
			
			return new Tuple2<String, Integer>(airline+","+airname, 1);
		});
		
		JavaPairRDD<String, Integer> reduceAirport = AirportOne.reduceByKey( (a,b) ->{
			return a+b;
		});
		
		JavaPairRDD<Integer, String> swap = reduceAirport.mapToPair(line -> {
			return new Tuple2<Integer, String>(line._2(), line._1());
		});
		
		JavaPairRDD<Integer, String> sortedAirport = swap.sortByKey(false);
		
		sortedAirport.saveAsTextFile(outputPathPartA);
		//Parte B
		
		JavaPairRDD<String,Counter> idPA_count = voli.mapToPair(line -> {
			String[] fields = line.split(",");
			String Pid = fields[5];
			String Aid = fields[6];
			int num_posti = Integer.parseInt(fields[9]);
			int num_prenotati = Integer.parseInt(fields[10]);
			String canc = fields[8];
			Counter cnt = new Counter(0,0,0);
			
			if(num_posti==num_prenotati) cnt.numFullyBooked++;
			if(canc.toLowerCase().compareTo("yes")==0) cnt.numCancelled++;
			cnt.numFlights++;
			
			return new Tuple2<String,Counter>(Pid+","+Aid, cnt);
		});
		
		JavaPairRDD<String,Counter> reduce = idPA_count.reduceByKey((a,b)->{
			return new Counter(a.numFullyBooked+b.numFullyBooked, a.numCancelled+b.numCancelled, a.numFlights+b.numFlights);
		});
		
		JavaPairRDD<String,Counter> filter = reduce.filter( line -> {
			if(line._2().numFullyBooked/line._2().numFlights >= 0.99 && line._2().numCancelled/line._2().numFlights >=0.05) return true;
			else return false;
		});
		
		
		filter.keys().saveAsTextFile(outputPathPartB);
		
		sc.close();
	}
}
