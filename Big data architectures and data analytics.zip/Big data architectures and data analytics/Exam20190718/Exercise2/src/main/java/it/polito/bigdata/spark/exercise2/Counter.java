package it.polito.bigdata.spark.exercise2;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Counter implements Serializable {
	public int numPatchesWindows;
    public int numPatchesUbuntu;

	public Counter(int numPatchesWindows, int numPatchesUbuntu) {
		this.numPatchesWindows = numPatchesWindows;
		this.numPatchesUbuntu = numPatchesUbuntu;
	}

	
}
