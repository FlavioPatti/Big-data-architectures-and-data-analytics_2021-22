package it.polito.bigdata.spark.exercise2;

import org.apache.spark.api.java.*;

import scala.Tuple2;

import java.util.ArrayList;

import org.apache.spark.SparkConf;

public class SparkDriver {

	public static void main(String[] args) {

		String inputPatches;
		String outputPathPartA;
		String outputPathPartB;

		inputPatches = args[0];
		outputPathPartA = args[1];
		outputPathPartB = args[2];

		// Create a configuration object and set the name of the application
		SparkConf conf = new SparkConf().setAppName("Spark Exam 2019_07_18 - Exercise #2");

		// Create a Spark Context object
		JavaSparkContext sc = new JavaSparkContext(conf);

		// *****************************************
		// Exercise 2 - Part A
		// *****************************************

		// Read the content of Patches.txt
		JavaRDD<String> patchesRDD = sc.textFile(inputPatches).cache();
		
		JavaRDD<String> filterRDD = patchesRDD.filter( line -> {
			String[] fields = line.split(",");
			String data = fields[1];
			Integer anno = Integer.parseInt(data.split("/")[0]);
			String nomeApplicazione = fields[2];
			
			if(anno == 2017 && (nomeApplicazione.compareTo("Windows 10")==0 || nomeApplicazione.compareTo("Ubuntu 18.04")==0 ) )
				return true;
			else return false;
		});
		
		JavaPairRDD<String,Counter> a = filterRDD.mapToPair(line -> {
			String[] fields = line.split(",");
			String mese = fields[1].split("/")[1];
			String pid = fields[0];
			Counter cnt = new Counter(0,0);
			String appName = fields[2];
			
			if(appName.compareTo("windows10")==0) cnt.numPatchesWindows++;
			else cnt.numPatchesUbuntu++;
			
			return new Tuple2<String,Counter>(pid+","+mese, cnt);
		}).reduceByKey((x,y)->{
			return new Counter(x.numPatchesWindows+y.numPatchesWindows, x.numPatchesUbuntu+y.numPatchesUbuntu);
		}).filter(line -> {
			if(line._2().numPatchesWindows != line._2().numPatchesUbuntu) return true;
			else return false;
		});
		
		JavaPairRDD<String,String> b = a.mapToPair(line -> {
			if(line._2().numPatchesWindows> line._2().numPatchesUbuntu) return new Tuple2<String,String>(line._1().split(",")[1], "W");
			else return new Tuple2<String,String>(line._1().split(",")[1], "U");
		});
		
		//PARTE B
		
		JavaRDD<String> rdd2018 = patchesRDD.filter(line -> {
			String data = line.split(",")[1].split("/")[0];
			if(data.compareTo("2018")==0) return true;
			else return false;
		});
		
		JavaPairRDD<String,Integer> c = rdd2018.mapToPair(line -> {
			String mese = line.split(",")[1].split("/")[1];
			String appName = line.split(",")[2];
			return new Tuple2<String,Integer>(mese+","+appName,1);
		}).reduceByKey((x,y)-> x+y).filter(line-> {
			if( line._2()>=4) return true;
			else return false;
		});
		
		JavaPairRDD<String,Integer> d = c.flatMapToPair(line -> {
			ArrayList<Tuple2<String,Integer>> list = new ArrayList();
			int mese = Integer.parseInt( line._1().split(",")[0] );
			String app = line._1().split(",")[1];
			list.add(new Tuple2<String,Integer>(line._1(),1) );
			
			int previousMese = mese-1;
			if(mese>1) list.add(new Tuple2<String,Integer>(previousMese+","+app, 1));
			
			int previousX2Mese = mese -2;
			if(mese>2) list.add(new Tuple2<String,Integer>(previousX2Mese+","+app, 1));
			
			return list.iterator();
		}).reduceByKey((x,y)-> x+y).filter(line -> {
			if(line._2()==3) return true;
			else return false;
		});
		
		
		
		
		sc.close();
	}
}
